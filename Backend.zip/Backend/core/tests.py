from rest_framework.test import APITestCase


class AutenticacaoTests(APITestCase):
    """Testa o fluxo completo: registro, login, endpoint protegido, logout."""

    DADOS_REGISTRO = {
        "username": "mih_contadora",
        "password": "SenhaForte123!",
        "first_name": "Mih",
        "email": "mih@example.com",
        "perfil": "CONTADOR",
    }

    def _registrar(self):
        return self.client.post("/api/auth/registro/", self.DADOS_REGISTRO, format="json")

    def test_registro_cria_usuario_e_retorna_token(self):
        resp = self._registrar()
        self.assertEqual(resp.status_code, 201)
        self.assertIn("token", resp.data)
        self.assertEqual(resp.data["usuario"]["perfil"], "CONTADOR")

    def test_registro_rejeita_username_duplicado(self):
        self._registrar()
        resp = self._registrar()
        self.assertEqual(resp.status_code, 400)

    def test_registro_rejeita_senha_fraca(self):
        dados = {**self.DADOS_REGISTRO, "password": "123"}
        resp = self.client.post("/api/auth/registro/", dados, format="json")
        self.assertEqual(resp.status_code, 400)

    def test_login_com_credenciais_corretas(self):
        self._registrar()
        resp = self.client.post(
            "/api/auth/login/",
            {"username": "mih_contadora", "password": "SenhaForte123!"},
            format="json",
        )
        self.assertEqual(resp.status_code, 200)
        self.assertIn("token", resp.data)

    def test_login_com_senha_errada_retorna_401(self):
        self._registrar()
        resp = self.client.post(
            "/api/auth/login/",
            {"username": "mih_contadora", "password": "senhaerrada"},
            format="json",
        )
        self.assertEqual(resp.status_code, 401)

    def test_me_sem_token_retorna_401(self):
        resp = self.client.get("/api/auth/me/")
        self.assertEqual(resp.status_code, 401)

    def test_me_com_token_retorna_dados_do_usuario(self):
        token = self._registrar().data["token"]
        resp = self.client.get("/api/auth/me/", HTTP_AUTHORIZATION=f"Token {token}")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.data["username"], "mih_contadora")
        self.assertEqual(resp.data["perfil"], "CONTADOR")

    def test_logout_invalida_o_token(self):
        token = self._registrar().data["token"]
        resp = self.client.post("/api/auth/logout/", HTTP_AUTHORIZATION=f"Token {token}")
        self.assertEqual(resp.status_code, 204)

        resp = self.client.get("/api/auth/me/", HTTP_AUTHORIZATION=f"Token {token}")
        self.assertEqual(resp.status_code, 401)

    def test_perfil_gestor_e_aceito(self):
        dados = {**self.DADOS_REGISTRO, "username": "gestor1", "perfil": "GESTOR"}
        resp = self.client.post("/api/auth/registro/", dados, format="json")
        self.assertEqual(resp.status_code, 201)
        self.assertEqual(resp.data["usuario"]["perfil"], "GESTOR")
