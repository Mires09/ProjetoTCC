from django.contrib import admin

from .models import (
    AnomaliaDetectada,
    ChecklistFechamento,
    ContaContabil,
    Empresa,
    Lancamento,
    TarefaChecklist,
    Usuario,
)


@admin.register(Usuario)
class UsuarioAdmin(admin.ModelAdmin):
    list_display = ("user", "perfil")


@admin.register(Empresa)
class EmpresaAdmin(admin.ModelAdmin):
    list_display = ("razao_social", "cnpj", "usuario_responsavel")
    search_fields = ("razao_social", "cnpj")


@admin.register(ContaContabil)
class ContaContabilAdmin(admin.ModelAdmin):
    list_display = ("codigo", "nome", "tipo", "empresa")
    list_filter = ("tipo", "empresa")


@admin.register(Lancamento)
class LancamentoAdmin(admin.ModelAdmin):
    list_display = ("data", "conta_contabil", "valor", "historico")
    list_filter = ("conta_contabil__empresa",)
    date_hierarchy = "data"


@admin.register(ChecklistFechamento)
class ChecklistFechamentoAdmin(admin.ModelAdmin):
    list_display = ("empresa", "mes_referencia", "ano_referencia", "status_geral")
    list_filter = ("empresa", "ano_referencia")


@admin.register(TarefaChecklist)
class TarefaChecklistAdmin(admin.ModelAdmin):
    list_display = ("nome", "checklist", "responsavel", "prazo", "status", "tipo")
    list_filter = ("status", "tipo")


@admin.register(AnomaliaDetectada)
class AnomaliaDetectadaAdmin(admin.ModelAdmin):
    list_display = ("lancamento", "metodo", "valor_desvio", "anomalo", "data_deteccao")
    list_filter = ("metodo", "anomalo")
