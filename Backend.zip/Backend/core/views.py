from django.contrib.auth import authenticate
from rest_framework import permissions, status
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Usuario
from .serializers import RegistroSerializer, UsuarioSerializer


class RegistroView(APIView):
    """POST /api/auth/registro/ — cria usuário + perfil, retorna o token."""

    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = RegistroSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        usuario = serializer.save()
        token, _ = Token.objects.get_or_create(user=usuario.user)
        return Response(
            {
                "token": token.key,
                "usuario": UsuarioSerializer(usuario).data,
            },
            status=status.HTTP_201_CREATED,
        )


class LoginView(APIView):
    """POST /api/auth/login/ — valida usuário/senha, retorna o token."""

    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username = request.data.get("username")
        password = request.data.get("password")

        if not username or not password:
            return Response(
                {"detail": "Informe username e password."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        user = authenticate(request, username=username, password=password)
        if user is None:
            return Response(
                {"detail": "Usuário ou senha inválidos."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        token, _ = Token.objects.get_or_create(user=user)
        usuario = getattr(user, "usuario", None)

        return Response(
            {
                "token": token.key,
                "usuario": UsuarioSerializer(usuario).data if usuario else None,
            }
        )


class LogoutView(APIView):
    """POST /api/auth/logout/ — invalida o token atual."""

    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        request.user.auth_token.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class MeView(APIView):
    """GET /api/auth/me/ — retorna os dados do usuário autenticado."""

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        usuario = getattr(request.user, "usuario", None)
        if usuario is None:
            return Response(
                {"detail": "Usuário autenticado não tem perfil associado."},
                status=status.HTTP_404_NOT_FOUND,
            )
        return Response(UsuarioSerializer(usuario).data)
