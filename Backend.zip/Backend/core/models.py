from django.conf import settings
from django.db import models


class Usuario(models.Model):
    """
    Extensão do usuário do Django com o campo de Perfil.
    Em vez de criar um model totalmente novo, usamos OneToOne com o
    User padrão do Django — assim ganhamos autenticação pronta
    (senha, hash, login) sem reimplementar nada.
    """

    class Perfil(models.TextChoices):
        CONTADOR = "CONTADOR", "Contador"
        GESTOR = "GESTOR", "Gestor"

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    perfil = models.CharField(max_length=20, choices=Perfil.choices, default=Perfil.CONTADOR)

    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} ({self.get_perfil_display()})"


class Empresa(models.Model):
    """Empresa-cliente atendida pelo escritório de contabilidade."""

    razao_social = models.CharField(max_length=200)
    cnpj = models.CharField(max_length=18, unique=True)
    usuario_responsavel = models.ForeignKey(
        Usuario, on_delete=models.PROTECT, related_name="empresas"
    )

    class Meta:
        verbose_name_plural = "Empresas"

    def __str__(self):
        return self.razao_social


class ContaContabil(models.Model):
    class Tipo(models.TextChoices):
        ATIVO = "ATIVO", "Ativo"
        PASSIVO = "PASSIVO", "Passivo"
        RECEITA = "RECEITA", "Receita"
        DESPESA = "DESPESA", "Despesa"

    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE, related_name="contas")
    codigo = models.CharField(max_length=20)
    nome = models.CharField(max_length=150)
    tipo = models.CharField(max_length=10, choices=Tipo.choices)

    class Meta:
        verbose_name_plural = "Contas contábeis"
        unique_together = ("empresa", "codigo")

    def __str__(self):
        return f"{self.codigo} — {self.nome}"


class Lancamento(models.Model):
    conta_contabil = models.ForeignKey(
        ContaContabil, on_delete=models.CASCADE, related_name="lancamentos"
    )
    valor = models.DecimalField(max_digits=14, decimal_places=2)
    data = models.DateField()
    historico = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.data} — {self.historico or self.conta_contabil.nome}: {self.valor}"


class ChecklistFechamento(models.Model):
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE, related_name="checklists")
    mes_referencia = models.PositiveSmallIntegerField()
    ano_referencia = models.PositiveSmallIntegerField()
    status_geral = models.CharField(max_length=30, default="Em andamento")

    class Meta:
        unique_together = ("empresa", "mes_referencia", "ano_referencia")
        ordering = ["-ano_referencia", "-mes_referencia"]

    def __str__(self):
        return f"{self.empresa} — {self.mes_referencia:02d}/{self.ano_referencia}"


class TarefaChecklist(models.Model):
    class Status(models.TextChoices):
        NAO_INICIADO = "NAO_INICIADO", "Não iniciado"
        EM_ANDAMENTO = "EM_ANDAMENTO", "Em andamento"
        CONCLUIDO = "CONCLUIDO", "Concluído"

    class Tipo(models.TextChoices):
        CONCILIACAO = "CONCILIACAO", "Conciliação"
        PROVISAO = "PROVISAO", "Provisão"
        IMPOSTO = "IMPOSTO", "Imposto"
        OUTRO = "OUTRO", "Outro"

    checklist = models.ForeignKey(
        ChecklistFechamento, on_delete=models.CASCADE, related_name="tarefas"
    )
    nome = models.CharField(max_length=150)
    responsavel = models.ForeignKey(
        Usuario, on_delete=models.SET_NULL, null=True, related_name="tarefas"
    )
    prazo = models.DateField()
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.NAO_INICIADO)
    tipo = models.CharField(max_length=20, choices=Tipo.choices, default=Tipo.OUTRO)

    def __str__(self):
        return self.nome


class AnomaliaDetectada(models.Model):
    class Metodo(models.TextChoices):
        ISOLATION_FOREST = "ISOLATION_FOREST", "Isolation Forest"
        Z_SCORE = "Z_SCORE", "Z-score"

    lancamento = models.OneToOneField(
        Lancamento, on_delete=models.CASCADE, related_name="anomalia"
    )
    metodo = models.CharField(max_length=20, choices=Metodo.choices)
    valor_desvio = models.FloatField()
    anomalo = models.BooleanField(default=False)
    data_deteccao = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        marca = "ANÔMALO" if self.anomalo else "normal"
        return f"Lançamento #{self.lancamento_id} — {self.valor_desvio:.2f} ({marca})"
