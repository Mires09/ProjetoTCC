from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers

from .models import Usuario


class UsuarioSerializer(serializers.ModelSerializer):
    """Representa o usuário autenticado: dados do Django User + Perfil."""

    username = serializers.CharField(source="user.username", read_only=True)
    first_name = serializers.CharField(source="user.first_name", read_only=True)
    email = serializers.EmailField(source="user.email", read_only=True)

    class Meta:
        model = Usuario
        fields = ["id", "username", "first_name", "email", "perfil"]


class RegistroSerializer(serializers.Serializer):
    """
    Cria um User do Django + o Usuario (com Perfil) vinculado, numa
    única chamada. Usado pelo endpoint de cadastro.
    """

    username = serializers.CharField(max_length=150)
    password = serializers.CharField(write_only=True)
    first_name = serializers.CharField(max_length=150, required=False, allow_blank=True)
    email = serializers.EmailField(required=False, allow_blank=True)
    perfil = serializers.ChoiceField(choices=Usuario.Perfil.choices, default=Usuario.Perfil.CONTADOR)

    def validate_username(self, value):
        if User.objects.filter(username=value).exists():
            raise serializers.ValidationError("Já existe um usuário com esse nome.")
        return value

    def validate_password(self, value):
        # Reaproveita os validadores de senha já configurados no Django
        # (tamanho mínimo, não ser só números, não ser muito comum etc.)
        validate_password(value)
        return value

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data["username"],
            password=validated_data["password"],
            first_name=validated_data.get("first_name", ""),
            email=validated_data.get("email", ""),
        )
        usuario = Usuario.objects.create(user=user, perfil=validated_data["perfil"])
        return usuario
