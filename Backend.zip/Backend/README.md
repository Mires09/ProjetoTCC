# Backend — Sistema Inteligente para Fechamento Contábil Mensal

Django + Django REST Framework. Modelos já batem com o ER definido no
Notion (página "Banco de Dados"): Usuario, Empresa, ContaContabil,
Lancamento, ChecklistFechamento, TarefaChecklist, AnomaliaDetectada.

## Por que Django (e não FastAPI)

O sistema é pesado em CRUD (checklist, tarefas, lançamentos, múltiplas
empresas) e precisa de autenticação com perfis. O Django já traz isso
pronto (ORM, admin, auth), o que evita reconstruir do zero — diferença
real de tempo num cronograma apertado. O React continua como frontend
separado, consumindo a API via REST (Django REST Framework).

## Como rodar

**1. Criar e ativar um ambiente virtual:**
```
python -m venv venv
venv\Scripts\activate        (Windows)
source venv/bin/activate     (Linux/Mac)
```

**2. Instalar as dependências:**
```
pip install -r requirements.txt
```

**3. Configurar o ambiente:**
```
copy .env.example .env       (Windows)
cp .env.example .env          (Linux/Mac)
```
Abra o `.env` e ajuste os valores. Pra testar rápido sem instalar
PostgreSQL agora, deixe `DB_ENGINE=sqlite` como já está.

**4. Rodar as migrações:**
```
python manage.py migrate
```

**5. Criar um superusuário (pra acessar o admin):**
```
python manage.py createsuperuser
```

**6. Rodar o servidor:**
```
python manage.py runserver
```

Acesse `http://127.0.0.1:8000/admin/` pra ver os dados pelo painel
administrativo do Django — útil pra inspecionar/editar dados sem
precisar do frontend ainda pronto.

## Quando for usar PostgreSQL de verdade

1. Crie o banco: `createdb fechamento_contabil` (ou pelo pgAdmin)
2. No `.env`, comente ou apague a linha `DB_ENGINE=sqlite`
3. Preencha `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT` com os dados
   da sua instalação
4. Rode `python manage.py migrate` de novo — ele recria tudo no Postgres

## Autenticação (endpoints)

Usa Token Authentication (o React manda `Authorization: Token <token>`
em cada requisição, sem depender de cookie/CSRF).

| Método | Rota | O que faz | Precisa de token? |
|---|---|---|---|
| POST | `/api/auth/registro/` | Cria usuário + perfil (Contador/Gestor), retorna o token | Não |
| POST | `/api/auth/login/` | Valida usuário/senha, retorna o token | Não |
| GET | `/api/auth/me/` | Dados do usuário autenticado | Sim |
| POST | `/api/auth/logout/` | Invalida o token atual | Sim |

## Rodar os testes

```
python manage.py test
```

## Status

✅ Testado nesta máquina: 9 testes automatizados (registro, login,
senha errada, endpoint protegido, logout, perfil Gestor, etc.) passam
com SQLite. Ainda não testei com PostgreSQL de verdade.

## Próximos passos (conforme o cronograma)

- [x] Autenticação e perfis de usuário
- [ ] CRUD de checklist e tarefas
- [ ] Validações automáticas (saldo x razão auxiliar)
- [ ] Detecção de anomalias (scikit-learn — ainda não está no requirements.txt, entra quando chegar nessa etapa)
- [ ] Frontend em React consumindo esta API
